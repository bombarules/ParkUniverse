package com.orbit.hub;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.print.PrintAttributes;
import android.content.ClipData;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import java.text.SimpleDateFormat;
import java.util.Locale;
import android.print.PrintManager;
import android.app.role.RoleManager;
import android.content.ContentValues;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.widget.Toast;
import android.net.Uri;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    // The app's own pages are served at this https address from inside the APK,
    // so the Mapbox key (which only allows bombarules.github.io) works offline-first.
    static final String HOST = "bombarules.github.io";
    static final String PREFIX = "/park-universe/";
    static final String START = "https://" + HOST + PREFIX + "index.html";

    private WebView web;
    private static final int REQ_HOME_ROLE = 7;
    private static final int REQ_PROJECTION = 42;
    private static final int REQ_FILE = 51;
    private static final int REQ_SAVE = 52;
    private static final int REQ_LOCATION = 53;
    private static final int REQ_NOTIFY = 54;
    private static final int REQ_MEDIA_LOC = 55;
    private static final int REQ_GEO = 56;
    private String pendingOpen = "due";
    private static final String DUE_CHANNEL = "due";
    private static final String EXTRA_OPEN = "open";
    private Uri lastCapture;
    private String pendingDueTitle;
    private String pendingDueText;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private String pendingText;
    private byte[] pendingBytes;
    private String pendingMime = "text/csv";
    private String pendingCode;
    private String pendingName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setGeolocationEnabled(true);
        // Follow the phone's larger text setting, but cap it so screens still fit.
        int zoom = Math.round(getResources().getConfiguration().fontScale * 100f);
        settings.setTextZoom(Math.max(85, Math.min(zoom, 115)));
        web.setWebViewClient(new AppClient());
        watchNetwork(settings);
        web.addJavascriptInterface(new Bridge(), "BombaNative");
        // Bridges the built-in apps were written for: PoolCommand and VoluntTold.
        web.addJavascriptInterface(new PoolBridge(), "PoolBridge");
        web.addJavascriptInterface(new AppBridge(), "AndroidApp");
        web.setWebChromeClient(new FileChooser());
        ShareService.sink = status -> {
            if (web != null) {
                final String js = "window.bombaShareStatus&&window.bombaShareStatus("
                        + status.toString() + ")";
                web.post(() -> web.evaluateJavascript(js, null));
            }
        };
        if (savedInstanceState == null) {
            // Opened from the "what's due" notification: go straight to that list.
            String open = getIntent() != null ? getIntent().getStringExtra(EXTRA_OPEN) : null;
            web.loadUrl(open != null ? START + "#" + open.replaceAll("[^a-z]", "") : START);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK) {
                    if (data != null && data.getData() != null) result = new Uri[]{data.getData()};
                    else if (cameraUri != null) { result = new Uri[]{cameraUri}; lastCapture = cameraUri; }
                } else if (cameraUri != null) {
                    try { getContentResolver().delete(cameraUri, null, null); } catch (Exception ignored) { }
                }
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
            cameraUri = null;
            return;
        }
        if (requestCode == REQ_GEO) {
            List<Uri> uris = new ArrayList<>();
            if (resultCode == RESULT_OK && data != null) {
                ClipData cd = data.getClipData();
                if (cd != null) for (int k = 0; k < cd.getItemCount(); k++) uris.add(cd.getItemAt(k).getUri());
                else if (data.getData() != null) uris.add(data.getData());
            }
            if (uris.isEmpty()) geoDone("{\"n\":0}"); else readGeoPhotos(uris);
            return;
        }
        if (requestCode == REQ_SAVE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && (pendingText != null || pendingBytes != null)) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                    if (os != null) os.write(pendingBytes != null ? pendingBytes : pendingText.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Couldn't save the file", Toast.LENGTH_LONG).show();
                }
            }
            pendingText = null;
            pendingBytes = null;
            return;
        }
        if (requestCode != REQ_PROJECTION) return;
        if (resultCode == RESULT_OK && data != null && pendingCode != null) {
            Intent svc = new Intent(this, ShareService.class);
            svc.putExtra(ShareService.EXTRA_RESULT_CODE, resultCode);
            svc.putExtra(ShareService.EXTRA_RESULT_DATA, data);
            svc.putExtra(ShareService.EXTRA_CODE, pendingCode);
            svc.putExtra(ShareService.EXTRA_NAME, pendingName);
            startForegroundService(svc);
        } else {
            try {
                JSONObject s = new JSONObject();
                s.put("state", "error");
                s.put("message", "Sharing was cancelled");
                ShareService.lastStatusJson = s.toString();
                if (ShareService.sink != null) ShareService.sink.onShareStatus(s);
            } catch (Exception ignored) {
            }
        }
        pendingCode = null;
        pendingName = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_LOCATION && geoCallback != null) {
            boolean ok = false;
            for (int r : results) if (r == PackageManager.PERMISSION_GRANTED) ok = true;
            geoCallback.invoke(geoOrigin, ok, false);
            geoCallback = null;
            geoOrigin = null;
        }
        if (requestCode == REQ_MEDIA_LOC) { launchGeoPicker(); return; }
        if (requestCode == REQ_NOTIFY) {
            boolean ok = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            if (ok && pendingDueTitle != null) postNote(pendingOpen.equals("due") ? 7001 : 7002, pendingDueTitle, pendingDueText, pendingOpen);
            pendingDueTitle = null;
            pendingDueText = null;
        }
    }

    /** No signal: show what the WebView already has saved (map pieces seen before) instead of blank tiles. */
    private void watchNetwork(final WebSettings settings) {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return;
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            boolean on = nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            settings.setCacheMode(on ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_CACHE_ELSE_NETWORK);
            cm.registerDefaultNetworkCallback(new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) { runOnUiThread(() -> settings.setCacheMode(WebSettings.LOAD_DEFAULT)); }
                @Override public void onLost(Network network) { runOnUiThread(() -> settings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK)); }
            });
        } catch (Exception ignored) {
        }
    }

    /** Photos -> items: a gallery picker that keeps each photo's GPS position. */
    private void launchGeoPicker() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(i, REQ_GEO);
        } catch (Exception e) {
            geoDone("{\"error\":\"Couldn't open the photo picker\"}");
        }
    }

    private void geoDone(String json) {
        final String js = "window.bombaGeoPhotosDone&&window.bombaGeoPhotosDone(" + json + ")";
        web.post(() -> web.evaluateJavascript(js, null));
    }

    private void readGeoPhotos(final List<Uri> uris) {
        new Thread(() -> {
            int sent = 0;
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US);
            for (Uri u : uris) {
                try {
                    Uri src = u;
                    if (Build.VERSION.SDK_INT >= 29) {
                        try {
                            Uri media = MediaStore.getMediaUri(this, u);
                            if (media != null && checkSelfPermission(android.Manifest.permission.ACCESS_MEDIA_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                                src = MediaStore.setRequireOriginal(media);
                            }
                        } catch (Exception ignored) { src = u; }
                    }
                    double lat = Double.NaN, lng = Double.NaN; long t = 0; int rot = 0;
                    InputStream in;
                    try { in = getContentResolver().openInputStream(src); } catch (Exception e) { src = u; in = getContentResolver().openInputStream(u); }
                    if (in == null) continue;
                    try {
                        ExifInterface ex = new ExifInterface(in);
                        float[] ll = new float[2];
                        if (ex.getLatLong(ll)) { lat = ll[0]; lng = ll[1]; }
                        String dt = ex.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL);
                        if (dt == null) dt = ex.getAttribute(ExifInterface.TAG_DATETIME);
                        if (dt != null) { try { t = fmt.parse(dt).getTime(); } catch (Exception ignored) { } }
                        int o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                        rot = o == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : o == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : o == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
                    } catch (Exception ignored) {
                    } finally { try { in.close(); } catch (Exception ignored) { } }
                    BitmapFactory.Options bo = new BitmapFactory.Options();
                    bo.inJustDecodeBounds = true;
                    try (InputStream s1 = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(s1, null, bo); }
                    int sample = 1;
                    while (Math.max(bo.outWidth, bo.outHeight) / (sample * 2) >= 1600) sample *= 2;
                    BitmapFactory.Options bo2 = new BitmapFactory.Options();
                    bo2.inSampleSize = sample;
                    Bitmap bmp;
                    try (InputStream s2 = getContentResolver().openInputStream(u)) { bmp = BitmapFactory.decodeStream(s2, null, bo2); }
                    if (bmp == null) continue;
                    if (rot != 0) { Matrix m = new Matrix(); m.postRotate(rot); Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true); bmp.recycle(); bmp = r; }
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, out);
                    bmp.recycle();
                    JSONObject o = new JSONObject();
                    if (!Double.isNaN(lat) && !(lat == 0 && lng == 0)) { o.put("lat", lat); o.put("lng", lng); }
                    if (t > 0) o.put("t", t);
                    o.put("b64", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
                    final String js = "window.bombaGeoPhoto&&window.bombaGeoPhoto(" + o.toString() + ")";
                    web.post(() -> web.evaluateJavascript(js, null));
                    sent++;
                } catch (Exception ignored) {
                }
            }
            geoDone("{\"n\":" + sent + "}");
        }).start();
    }

    /** One quiet notification a day when tests, trees or tasks are due; tapping it opens the list. */
    private void postDue(String title, String text) { postNote(7001, title, text, "due"); }

    private void postNote(int id, String title, String text, String openWhat) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(DUE_CHANNEL, "Work reminders", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("What's due, winter storm warnings and new resident reports");
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(this, MainActivity.class);
            open.putExtra(EXTRA_OPEN, openWhat == null ? "due" : openWhat);
            open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, id, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, DUE_CHANNEL) : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(pi)
                    .setAutoCancel(true);
            nm.notify(id, b.build());
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        final String openWhat = intent.getStringExtra(EXTRA_OPEN);
        final boolean due = openWhat != null;
        // Home button pressed while Park Universe is the home app: back to the map.
        if (web != null) {
            web.post(() -> {
                if (due) {
                    String u0 = web.getUrl();
                    String w = openWhat.replaceAll("[^a-z]", "");
                    if (u0 == null || !u0.startsWith(START)) web.loadUrl(START + "#" + w);
                    else web.evaluateJavascript("window.bombaOpen&&window.bombaOpen('" + w + "')", null);
                    return;
                }
                String u = web.getUrl();
                if (u == null || !u.startsWith(START)) web.loadUrl(START);   // inside an app: back to the map
                else web.evaluateJavascript("window.bombaHome&&window.bombaHome()", null);
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private boolean isDefaultHome() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        ResolveInfo info = getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
        return info != null && info.activityInfo != null
                && getPackageName().equals(info.activityInfo.packageName);
    }

    private void openHomeSwitch() {
        // Not the home app yet: the system asks with its own dialog (Android 10+).
        if (!isDefaultHome() && Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = (RoleManager) getSystemService(ROLE_SERVICE);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)
                    && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_HOME_ROLE);
                return;
            }
        }
        // Already home (switch back) or older Android: system home settings list.
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private static boolean ours(Uri u) {
        if (u == null) return false;
        if ("file".equals(u.getScheme())) return true;
        return "https".equals(u.getScheme()) && HOST.equals(u.getHost())
                && u.getPath() != null && u.getPath().startsWith(PREFIX);
    }

    private static String mime(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }

    /** Serves the APK's assets at https://bombarules.github.io/park-universe/ and sends other links to the phone. */
    private class AppClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if ("https".equals(u.getScheme()) && HOST.equals(u.getHost())
                    && u.getPath() != null && u.getPath().startsWith(PREFIX)) {
                String path = u.getPath().substring(PREFIX.length());
                if (path.isEmpty()) path = "index.html";
                Map<String, String> headers = new HashMap<>();
                headers.put("Access-Control-Allow-Origin", "*");
                headers.put("Cache-Control", "no-cache");
                try {
                    InputStream in = getAssets().open(path);
                    String type = mime(path);
                    boolean text = type.startsWith("text/") || type.endsWith("javascript") || type.endsWith("json") || type.endsWith("svg+xml");
                    return new WebResourceResponse(type, text ? "UTF-8" : null, 200, "OK", headers, in);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", headers,
                            new ByteArrayInputStream(new byte[0]));
                }
            }
            return super.shouldInterceptRequest(view, req);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (ours(u)) return false;
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, u);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception ignored) {
            }
            return true;
        }
    }

    /** Photo picker for the apps' "add photo" buttons; uses the camera when the page asks for it. */
    private class FileChooser extends WebChromeClient {
        /** GPS for the asset inventory: only our own pages may ask, and Android asks the person once. */
        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            Uri o = Uri.parse(origin);
            if (!"https".equals(o.getScheme()) || !HOST.equals(o.getHost())) { callback.invoke(origin, false, false); return; }
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                callback.invoke(origin, true, false);
            } else {
                geoCallback = callback;
                geoOrigin = origin;
                requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            }
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            cameraUri = null;
            lastCapture = null;
            String[] types = params.getAcceptTypes();
            String type = (types != null && types.length > 0 && types[0] != null && !types[0].isEmpty()) ? types[0] : "*/*";
            Intent intent = null;
            if (params.isCaptureEnabled() && Build.VERSION.SDK_INT >= 29 && type.startsWith("image")) {
                try {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Images.Media.DISPLAY_NAME, "park_" + System.currentTimeMillis() + ".jpg");
                    v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Park Universe");
                    cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                    if (cameraUri != null) {
                        intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    }
                } catch (Exception e) {
                    cameraUri = null;
                }
            }
            if (intent == null) {
                Intent get = new Intent(Intent.ACTION_GET_CONTENT);
                get.addCategory(Intent.CATEGORY_OPENABLE);
                get.setType(type);
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) get.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent = Intent.createChooser(get, "Choose a file");
            }
            try {
                startActivityForResult(intent, REQ_FILE);
                return true;
            } catch (Exception e) {
                fileCallback.onReceiveValue(null);
                fileCallback = null;
                return false;
            }
        }
    }

    /** PoolCommand: share CSV exports and backups, keep the screen on, report the app version. */
    public class PoolBridge {
        @JavascriptInterface
        public void share(final String title, final String text) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, title);
                send.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(send, title));
            });
        }

        @JavascriptInterface
        public void keepScreenOn(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public String version() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "";
            }
        }
    }

    /** VoluntTold + Park Universe: save files through Android's "save as" screen. */
    public class AppBridge {
        @JavascriptInterface
        public void saveBase64(final String name, final String mime, final String b64) {
            try {
                pendingBytes = Base64.decode(b64, Base64.DEFAULT);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Couldn't save the file", Toast.LENGTH_LONG).show());
                return;
            }
            pendingText = null;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Couldn't save the file", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void saveText(final String name, final String text) {
            pendingText = text;
            pendingBytes = null;
            String n = name == null ? "" : name.toLowerCase();
            final String type = n.endsWith(".geojson") || n.endsWith(".json") ? "application/json" : "text/csv";
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(type);
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Couldn't save the file", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    /** Bridge the page's existing UI expects, under its original name. */
    public class Bridge {

        @JavascriptInterface
        public void requestApps() {
            new Thread(() -> {
                JSONArray arr = new JSONArray();
                try {
                    PackageManager pm = getPackageManager();
                    Intent main = new Intent(Intent.ACTION_MAIN);
                    main.addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
                    List<ResolveInfo> sorted = new ArrayList<>(apps);
                    Collections.sort(sorted, new ResolveInfo.DisplayNameComparator(pm));
                    for (ResolveInfo ri : sorted) {
                        JSONObject o = new JSONObject();
                        o.put("label", String.valueOf(ri.loadLabel(pm)));
                        o.put("pkg", ri.activityInfo.packageName);
                        o.put("icon", iconDataUri(pm, ri));
                        arr.put(o);
                    }
                } catch (Exception ignored) {
                }
                final String js = "window.bombaApps&&window.bombaApps(" + arr.toString() + ")";
                web.post(() -> web.evaluateJavascript(js, null));
            }).start();
        }

        private String iconDataUri(PackageManager pm, ResolveInfo ri) {
            try {
                Drawable d = ri.loadIcon(pm);
                int size = 96;
                Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bmp);
                d.setBounds(0, 0, size, size);
                d.draw(canvas);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
                return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            }
        }

        /** "What's due" reminder. Asks for notification permission the first time (Android 13+). */
        @JavascriptInterface
        public void notifyDue(final String title, final String text) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    pendingDueTitle = title;
                    pendingDueText = text;
                    pendingOpen = "due";
                    requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
                    return;
                }
                postDue(title, text);
            });
        }

        /** Other reminders (winter storm warning, resident reports). Tapping opens that screen. */
        @JavascriptInterface
        public void notify(final String title, final String text, final String openWhat) {
            runOnUiThread(() -> {
                String w = openWhat == null ? "work" : openWhat.replaceAll("[^a-z]", "");
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    pendingDueTitle = title;
                    pendingDueText = text;
                    pendingOpen = w;
                    requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
                    return;
                }
                postNote(w.equals("storm") ? 7003 : 7004, title, text, w);
            });
        }

        /** Photos -> items: asks once for access to photo locations, then opens the picker. */
        @JavascriptInterface
        public void pickGeoPhotos() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 29
                        && checkSelfPermission(android.Manifest.permission.ACCESS_MEDIA_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{android.Manifest.permission.ACCESS_MEDIA_LOCATION}, REQ_MEDIA_LOC);
                    return;
                }
                launchGeoPicker();
            });
        }

        /** Prints what's on screen (QR tag sheets, the monthly summary) or saves it as a PDF. */
        @JavascriptInterface
        public void printPage(final String name) {
            runOnUiThread(() -> {
                try {
                    String job = name == null || name.isEmpty() ? "Park Universe" : name;
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    pm.print(job, web.createPrintDocumentAdapter(job), new PrintAttributes.Builder().build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Printing isn't available on this phone", Toast.LENGTH_LONG).show();
                }
            });
        }

        /** A QR tag was scanned with the camera: don't leave that picture in the phone's gallery. */
        @JavascriptInterface
        public void discardCapture() {
            runOnUiThread(() -> {
                if (lastCapture != null) {
                    try { getContentResolver().delete(lastCapture, null, null); } catch (Exception ignored) { }
                    lastCapture = null;
                }
            });
        }

        @JavascriptInterface
        public void launch(final String pkg) {
            runOnUiThread(() -> {
                try {
                    Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    }
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void pickWallpaper() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_SET_WALLPAPER);
                    startActivity(Intent.createChooser(i, "Wallpaper"));
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void homeSettings() {
            runOnUiThread(MainActivity.this::openHomeSwitch);
        }

        @JavascriptInterface
        public void startScreenShare(final String code, final String name) {
            runOnUiThread(() -> {
                pendingCode = code;
                pendingName = name;
                MediaProjectionManager mpm =
                        (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
            });
        }

        @JavascriptInterface
        public void stopScreenShare() {
            stopService(new Intent(MainActivity.this, ShareService.class));
            ShareService.lastStatusJson = "{}";
        }

        @JavascriptInterface
        public void setKeepAwake(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public String shareState() {
            return ShareService.lastStatusJson;
        }
    }
}
